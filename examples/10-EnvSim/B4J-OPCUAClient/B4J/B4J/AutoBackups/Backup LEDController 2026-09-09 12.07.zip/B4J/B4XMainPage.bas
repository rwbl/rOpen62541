﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

#Macro: Title, Export B4XPages, ide://run?File=%B4X%\Zipper.jar&Args=%PROJECT_NAME%.zip

Sub Class_Globals
	' Info
	Private VERSION as string = "XEdge32 LEDController v20260909"
	
	' Base
	Private Root As B4XView
	Private xui As XUI

	' Communication
	Private ws As WebSocketClient
	
	' XEdge32 
	' Credentials
	Private IP As String = "ws://xedge32.local/LEDController/"
	' Commands
	Private LED_ON As String = "led_on"
	Private LED_OFF As String = "led_off"
	Private LED_TOGGLE As String = "led_toggle"	'ignore

	Private TileConnect As HMITilesIO
	Private TileLED As HMITilesIO
	Private TileConnected As HMITilesIO
End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")
	
	' UI
	B4XPages.SetTitle(Me, VERSION)
	Root.Color = xui.
	
	' HMITilesIO
	Sleep(1)	' MANDATORY
	TileConnect.State = False
	TileLED.State = False
	TileConnected.Value = "Disconnected"
	TileConnected.ValueFontSize = 14
End Sub

Sub ConnectToXedge
	' Target the clean global route we created (Use ws:// instead of http://)
	Dim TargetUrl As String = IP
	
	If Not(ws.Connected) Then
		Log($"[ConnectToXedge] Starting url=${TargetUrl}"$)

		' Init
		Log($"[ConnectToXedge] Initializing..."$)
		ws.Initialize("ws")

		Log("[ConnectToXedge] Connecting to Xedge WebSocket...")
		' Connect > event ws_Connected is raised
		ws.Connect(TargetUrl)
	Else
		Log($"[ConnectToXedge] Already connected to url=${TargetUrl}"$)
	End If
End Sub

' Event triggers automatically when connection is established
Sub ws_Connected
	Log("WebSocket Connected successfully!")
	' Give the ESP32 background thread 50ms to start its read loop
	Sleep(50)
	TileConnected.Value = "Connected"
End Sub

' Event triggers when the ESP32 writes back to B4J
Sub ws_TextMessage(Message As String)
	Log($"[ws_TextMessage] Response=${Message}"$)
	' ws.close
End Sub

Sub ws_Closed (Reason As String)
	Log($"[ws_Closed] Connection closed: ${Reason}"$)
	TileConnect.State = False
	TileConnected.Value = "Disconnected"
End Sub

'Private Sub WebSocketSetAcceptAll (WebSocket As WebSocketClient)	'ignore
'	Dim ssl As JavaObject
'	ssl.InitializeNewInstance("org.eclipse.jetty.util.ssl.SslContextFactory.Client", Array(True))
'	Dim ClientConnector As JavaObject
'	ClientConnector.InitializeNewInstance("org.eclipse.jetty.io.ClientConnector", Null)
'	ClientConnector.RunMethod("setSslContextFactory", Array(ssl))
'	Dim Infos As JavaObject
'	Infos.InitializeArray("org.eclipse.jetty.io.ClientConnectionFactory$Info", Array())
'	Dim HttpTransport As JavaObject
'	HttpTransport.InitializeNewInstance("org.eclipse.jetty.client.transport.HttpClientTransportDynamic", Array(ClientConnector, Infos))
'	Dim HttpClient As JavaObject
'	HttpClient.InitializeNewInstance("org.eclipse.jetty.client.HttpClient", Array(HttpTransport))
'	Dim jo As JavaObject = WebSocket
'	Dim wsc As JavaObject
'	wsc.InitializeNewInstance("org.eclipse.jetty.websocket.client.WebSocketClient", Array(HttpClient))
'	jo.SetField("wsc", wsc)
'End Sub

'==============================================================
' HMITILESIO Events
'==============================================================

Private Sub TileConnect_Click(State As Boolean, Value As String)
	State = Not(State)
	If State Then
		ConnectToXedge
	Else
		If ws.Connected Then
			ws.close
		End If
	End If
	TileConnect.State = State
End Sub

Private Sub TileLED_Click(State As Boolean, Value As String)
	Dim cmd As String
	If ws.Connected Then
		State = Not(State)
		TileLED.State = State
		' Create comman and send async
		cmd = IIf(State, LED_ON, LED_OFF)
		Log($"[TileLED] sending command=${cmd}"$)
		ws.SendTextASync(cmd)
		Wait For ws_TextMessage (Message As String)
		Log($"[TileLED] received=${Message}"$)
	End If
End Sub

'Private Sub Button1_Click
'	Log("[Button1] SendTextASync led_on")
'	If ws.Connected Then
'		ws.SendTextASync(LED_TOGGLE)
'		Wait For ws_TextMessage (Message As String)
'		Log($"[Button1] received=${Message}"$)
'	End If
'End Sub
