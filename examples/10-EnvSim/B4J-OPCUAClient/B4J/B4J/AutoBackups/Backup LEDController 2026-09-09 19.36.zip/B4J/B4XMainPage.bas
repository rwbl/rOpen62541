﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

#Macro: Title, Export B4XPages, ide://run?File=%B4X%\Zipper.jar&Args=%PROJECT_NAME%.zip

Sub Class_Globals
	' Info
	Private VERSION As String = "XEdge32 LEDController v20260909"
	
	' UI Base
	Private xui As XUI
	Private Root As B4XView

	' UI HMITilesIO
	Private TileConnect As HMITilesIO
	Private TileLED As HMITilesIO
	Private TileConnected As HMITilesIO

	' Communication
	Private ws As WebSocketClient
	
	' XEdge32 
	' Credentials
	Private IP As String = "ws://xedge32.local/LEDController/"
	' Commands
	Private PING 		As String = "ping"
	Private LED_ON 		As String = "led_on"
	Private LED_OFF 	As String = "led_off"
	Private BLINK_ON 	As String = "blink_on"
	Private BLINK_OFF 	As String = "blink_off"
	Private LED_TOGGLE	As String = "led_toggle"	'ignore

	' KeepAlive Timer
	Private TimerKeepAlive As Timer
	Private TIMERKEEPALIVE_INTERVAL As Long = 15000	' Every 15 secs because XEdge32 closes connection after 30 secs

End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	' UI Base
	Root = Root1
	Root.LoadLayout("MainPage")
	
	' UI B4XPages
	B4XPages.SetTitle(Me, VERSION)
	Root.Color = xui.Color_LightGray
	
	' HMITilesIO
	Sleep(50)	' MANDATORY
	TileConnect.State = False
	TileConnect.Footer = ""
	TileLED.State = False
	TileLED.Footer = "Pin D2"
	TileConnected.Value = "Disconnected"
	TileConnected.ValueFontSize = 14
	TileConnected.Footer = ""
	
	' Timer
	TimerKeepAlive.Initialize("TimerKeepAlive", TIMERKEEPALIVE_INTERVAL)
	TimerKeepAlive.Enabled = False
End Sub

'==============================================================
' KEEPALIVETIMER
'==============================================================

Sub TimerKeepAlive_Tick
	If ws.Connected Then
		ws.SendTextASync(PING)
	End If
End Sub

'==============================================================
' XEDGE
'==============================================================

Sub ConnectToXedge
	' Target the clean global route we created (Use ws:// instead of http://)
	Dim TargetUrl As String = IP
	
	If Not(ws.Connected) Then
		ToLog($"[ConnectToXedge] Starting url=${TargetUrl}"$)
		TileConnected.Value = "Connecting..."
		' Init
		ToLog($"[ConnectToXedge] Initializing..."$)
		ws.Initialize("ws")

		ToLog("[ConnectToXedge] Connecting to Xedge WebSocket...")
		' Connect > event ws_Connected is raised
		ws.Connect(TargetUrl)
	Else
		ToLog($"[ConnectToXedge] Already connected to url=${TargetUrl}"$)
	End If
End Sub

'==============================================================
' WEBSOCKETCLIENT Events
'==============================================================

' Event triggers automatically when connection is established
Sub ws_Connected
	ToLog("WebSocket Connected successfully!")
	' Give the ESP32 background thread 50ms to start its read loop
	Sleep(50)
	TileConnected.Value = "Connected"
	TimerKeepAlive.Enabled = True
End Sub

' Event triggers when the ESP32 writes back to B4J
Sub ws_TextMessage(Message As String)
	ToLog($"[ws_TextMessage] Response=${Message}"$)
	' ws.close
End Sub

' Note:
' [ws_Closed] Connection closed: Connection Idle Timeout
Sub ws_Closed (Reason As String)
	ToLog($"[ws_Closed] Connection closed: ${Reason}"$)
	TileConnect.State = False
	TileConnected.Value = "Disconnected"
	TimerKeepAlive.Enabled = True
End Sub

'==============================================================
' HMITILESIO Events
'==============================================================

Private Sub TileConnect_Click(State As Boolean, Value As String)
	State = Not(State)
	If State Then
		ConnectToXedge
	Else
		If ws.Connected Then
			ws.close
		End If
	End If
	TileConnect.State = State
End Sub

Private Sub TileLED_Click(State As Boolean, Value As String)
	Dim cmd As String
	If ws.Connected Then
		State = Not(State)
		TileLED.State = State
		' Create comman and send async
		cmd = IIf(State, LED_ON, LED_OFF)
		cmd = IIf(State, LED_ON, LED_OFF)
		ToLog($"[TileLED] sending command=${cmd}"$)
		ws.SendTextASync(cmd)
		Wait For ws_TextMessage (Message As String)
		ToLog($"[TileLED] received=${Message}"$)
	End If
End Sub

'Private Sub Button1_Click
'	Log("[Button1] SendTextASync led_on")
'	If ws.Connected Then
'		ws.SendTextASync(LED_TOGGLE)
'		Wait For ws_TextMessage (Message As String)
'		Log($"[Button1] received=${Message}"$)
'	End If
'End Sub

Private Sub GetTime As String
	Return $"${DateTime.Time(DateTime.Now)}"$
End Sub

Private Sub ToLog(msg As String)
	Log($"${GetTime} ${msg}"$)
End Sub