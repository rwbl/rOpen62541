﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
' Project:		XEdge32 Explore
' Brief:		XEdge32 IoT LED Controller with B4J & HMITilesIO
' Date:			2026-09-09
' Author:		Robert W.B. Linn (c) 2026 - MIT
' Description:	Experiment: 
A high-performance, asynchronous IoT control bridge linking a desktop B4J (B4XPages) interface To an ESP32 microcontroller running XEdge32 firmware. 
This project implements a full-duplex WebSocket connection To safely manipulate physical GPIO states in real time without CPU blocking Or thread exhaustion.

' DependsOn:	jWebSocketClient, HMITilesIO
' 
' XEdge32 Log Example:
'11: LED Controller v20260909
'27: Success: Pin 2 successfully allocated.
'52: WebSocket Bridge Active: B4J Connected successfully!
'61: Received from B4J: LED_ON
'61: Received from B4J: LED_OFF
'61: Received from B4J: BLINK_ON
'61: Received from B4J: BLINK_OFF
'57: WebSocket closed: socketclosed
 
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

#Macro: Title, Export B4XPages, ide://run?File=%B4X%\Zipper.jar&Args=%PROJECT_NAME%.zip

Sub Class_Globals
	' Info
	Private VERSION As String = "XEdge32 LEDController v20260909"
	
	' UI Base
	Private xui As XUI
	Private Root As B4XView

	' UI HMITilesIO
	Private TileConnect As HMITilesIO
	Private TileConnected As HMITilesIO
	Private TileLEDOnOff As HMITilesIO
	Private TileLEDBlink As HMITilesIO

	' Communication
	Private ws As WebSocketClient
	
	' XEdge32 
	' Credentials
	Private IP As String = "ws://xedge32.local/LEDController/"
	' Commands
	Private PING 		As String = "ping"
	Private LED_ON 		As String = "led_on"
	Private LED_OFF 	As String = "led_off"
	Private BLINK_ON 	As String = "blink_on"
	Private BLINK_OFF 	As String = "blink_off"
	Private LED_TOGGLE	As String = "led_toggle"	'ignore

	' KeepAlive Timer
	Private TimerKeepAlive As Timer
	Private TIMERKEEPALIVE_INTERVAL As Long = 15000	' Every 15 secs because XEdge32 closes connection after 30 secs

End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	' UI Base
	Root = Root1
	Root.LoadLayout("MainPage")
	
	' UI B4XPages
	B4XPages.SetTitle(Me, VERSION)
	Root.Color = xui.Color_LightGray
	
	' HMITilesIO
	Sleep(50)	' MANDATORY
	TileConnect.State = False
	TileConnect.Footer = ""
	TileLEDOnOff.State = False
	TileLEDOnOff.Footer = "Pin D2"
	TileLEDBlink.State = False
	TileLEDBlink.Footer = ""
	TileConnected.Value = "Disconnected"
	TileConnected.ValueFontSize = 14
	TileConnected.Footer = ""
	
	' Timer
	TimerKeepAlive.Initialize("TimerKeepAlive", TIMERKEEPALIVE_INTERVAL)
	TimerKeepAlive.Enabled = False
End Sub

'==============================================================
' KEEPALIVETIMER
'==============================================================

' Send ping command in regular interval to ensure websocketclient connection keeps connected
Sub TimerKeepAlive_Tick
	If ws.Connected Then
		ws.SendTextASync(PING)
	End If
End Sub

'==============================================================
' XEDGE
'==============================================================

Sub ConnectToXedge
	' Target the clean global route we created (Use ws:// instead of http://)
	Dim TargetUrl As String = IP
	
	If Not(ws.Connected) Then
		ToLog($"[ConnectToXedge] Starting url=${TargetUrl}"$)
		TileConnected.Value = "Connecting..."
		' Init
		ToLog($"[ConnectToXedge] Initializing..."$)
		ws.Initialize("ws")

		ToLog("[ConnectToXedge] Connecting to Xedge WebSocket...")
		' Connect > event ws_Connected is raised
		ws.Connect(TargetUrl)
	Else
		ToLog($"[ConnectToXedge] Already connected to url=${TargetUrl}"$)
	End If
End Sub

'==============================================================
' WEBSOCKETCLIENT Events
'==============================================================

' Event triggers automatically when connection is established
Sub ws_Connected
	ToLog("WebSocket Connected successfully!")
	' Give the ESP32 background thread 50ms to start its read loop
	Sleep(50)
	TileConnected.Value = "Connected"
	TimerKeepAlive.Enabled = True
End Sub

' Event triggers when the ESP32 writes back to B4J
Sub ws_TextMessage(Message As String)
	ToLog($"[ws_TextMessage] Response=${Message}"$)
	' ws.close
End Sub

' Note:
' [ws_Closed] Connection closed: Connection Idle Timeout
Sub ws_Closed (Reason As String)
	ToLog($"[ws_Closed] Connection closed: ${Reason}"$)
	TileConnect.State = False
	TileConnected.Value = "Disconnected"
	TimerKeepAlive.Enabled = True
End Sub

'==============================================================
' HMITILESIO Events
'==============================================================

Private Sub TileConnect_Click(State As Boolean, Value As String)
	State = Not(State)
	If State Then
		ConnectToXedge
	Else
		If ws.Connected Then
			ws.close
		End If
	End If
	TileConnect.State = State
End Sub

Private Sub TileLEDOnOff_Click(State As Boolean, Value As String)
	Dim cmd As String
	If ws.Connected Then
		State = Not(State)
		TileLEDOnOff.State = State
		' Create comman and send async
		cmd = IIf(State, LED_ON, LED_OFF)
		ToLog($"[TileLEDOnOff] sending command=${cmd}"$)
		ws.SendTextASync(cmd)
		Wait For ws_TextMessage (Message As String)
		ToLog($"[TileLEDOnOff] received=${Message}"$)
	End If
End Sub

Private Sub TileLEDBlink_Click(State As Boolean, Value As String)
	Dim cmd As String
	If ws.Connected Then
		State = Not(State)
		TileLEDBlink.State = State
		' Create comman and send async
		cmd = IIf(State, BLINK_ON, BLINK_OFF)
		ToLog($"[TileLEDBlink] sending command=${cmd}"$)
		ws.SendTextASync(cmd)
		Wait For ws_TextMessage (Message As String)
		ToLog($"[TileLEDBlink] received=${Message}"$)
	End If
End Sub

'==============================================================
' HELPER
'==============================================================

Private Sub GetTime As String
	Return $"${DateTime.Time(DateTime.Now)}"$
End Sub

Private Sub ToLog(msg As String)
	Log($"${GetTime} ${msg}"$)
End Sub